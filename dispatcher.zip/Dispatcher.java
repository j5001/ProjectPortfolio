package dispatchsimulator;

import java.util.*;

public class Dispatcher 
{
	
	private PriorityQueue<Process> readyQueue;
	private ArrayList<Process> blockingList;
	private Process cpu;


	public Dispatcher()
	{
		readyQueue = new PriorityQueue<Process>();
		blockingList = new ArrayList<Process>();
		
	}
	
	/**
	 * adds a new process to the ready queue
	 */
	public void addProcessToQueue(Process p)
	{
		p.setStatus("ready");
		readyQueue.add(p);

	}
	
	/**
	 *  blocks process currently
	 *  in ReadyQueue sending it to
	 *  blockedList
	 */
	public void blockProcessInQueue(Process p)
	{
		
		readyQueue.remove(p);
		p.setStatus("blocked");
		blockingList.add(p);
		
		
	}
	
	/**
	 *  runs process in ready queue
	 */
	public void runProcessInQueue(Process p)
	{
		if(cpu!=null)
		{
			readyQueue.add(cpu);
			cpu = null;
		}
		
		readyQueue.remove(p);
		p.setStatus("running");
		cpu = p;
	}
	
	/** 
	 *  kills process in ready queue
	 */
	public void killProcessInQueue(Process p)
	{
		readyQueue.remove(p);
	}
	
	/**
	 *  unblocks process in the blockedLIst
	 *  and places it in the ready Queue
	 */
	public void unblockProcessInList(Process p)
	{
		blockingList.remove(p);
		p.setStatus("ready");
		readyQueue.add(p);
	}
	/**
	 * kills process in the blockedList
	 */
	public void killProcessInList(Process p)
	{
	/**
	 * takes a process in the blockedList and
	 * runs it 
	 */
		blockingList.remove(p);
	}
	
	public void runProcessInList(Process p)
	{
		if(cpu!=null)
		{
			blockingList.add(cpu);
			cpu = null;
		}
		
		blockingList.remove(p);
		p.setStatus("running");
		cpu = p;
	}
	
	
	/**
	 * sends a process currently running
	 * to the blockedList
	 * 
	 * doesn't check if the ri
	 */
	public void blockProcessInCpu(Process p)
	{
	  if(cpu==p)
	  {
		  p.setStatus("blocked"); 
		  blockingList.add(p);
		  cpu = null;
	  }
	  
	  else
		  System.out.println("Error: Process is not running, cannot block.");
		
		
			
		
	}
	
	/**
	 * stops a process fro running
	 * puts it back in the ready queue
	 * 
	 */
	public void stopProcessInCpu(Process p)
	{
	  if(cpu==p)
	  {
		  p.setStatus("ready");
		  cpu = null; 
		  readyQueue.add(p);
	  }
	  
	  else
		  System.out.println("Error: Process not running, cannot stop.");
		
	}
	
	public void killProcessInCpu(Process p)
	{
		if(cpu==p)
		  {
			  cpu = null; 
		  }
		  
		else
			  System.out.println("Error: Process not running, cannot kill.");
			
	}
	
	public PriorityQueue<Process> getReadyQueue()
	{
		return readyQueue;
	}
	
	public ArrayList<Process> getBlockingList()

	{
		return blockingList;
	}
	
	public Process getCpu()
	{
		return cpu;
	}

	public void printCpu()
	{
	
		System.out.println("\t" +"CPU:");
		if(cpu!=null)
			System.out.println("\t" +cpu.getPid() + "\t" + cpu.getName() + "\t" + cpu.getPriority() + "\t" + cpu.getStatus());
		else
			System.out.println("\t" + "No process in CPU");
		System.out.println("");
	}
	public void printBlockingList()
	{
		System.out.println("\t" +"Blocking List:");
		for(int x=0;x<blockingList.size();x++)
		{
			System.out.println("\t" + blockingList.get(x).getPid() + "\t" + blockingList.get(x).getName() + "\t" + blockingList.get(x).getPriority() + "\t" + blockingList.get(x).getStatus());
		}
		System.out.println();
	}
	
	public void printReadyQueue()
	{
		System.out.println("\t" +"Ready Queue:");
		Object[] tempArray = readyQueue.toArray();
		
		for(int x =0;x<tempArray.length;x++)
		{
			System.out.println("\t" + ((Process)tempArray[x]).getPid() + "\t" + ((Process)tempArray[x]).getName() + "\t" + ((Process)tempArray[x]).getPriority() + "\t" + ((Process)tempArray[x]).getStatus());

		}
		System.out.println();
		
	}
	
	public void printDispatcher()
	{
	System.out.println("Dispatcher System State:");
		printCpu();
		printReadyQueue();
		printBlockingList();
	}

}
