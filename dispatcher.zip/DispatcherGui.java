package dispatchsimulator;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JList;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultListModel;
import javax.swing.SwingConstants;


public class DispatcherGui extends JFrame {
	private Dispatcher d1 = new Dispatcher();
	private JPanel contentPane;
	private JTextField nameTextBox;
	private JTextField priorityTextBox;
	private final Action addProcess = new SwingAction();
	private JList pqList;
	private JList bList;
	private final Action pqKill = new SwingAction_1();
	private final Action pqBlock = new SwingAction_2();
	private final Action pqRun = new SwingAction_3();
	private JLabel lblRunningProcess;
	private final Action bKill = new SwingAction_4();
	private final Action bUnblock = new SwingAction_5();
	private final Action bRun = new SwingAction_6();
	private final Action cpuKill = new SwingAction_7();
	private final Action cpuBlock = new SwingAction_8();
	private final Action cpuStop = new SwingAction_9();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DispatcherGui frame = new DispatcherGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DispatcherGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 1200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		pqList = new JList();
		bList = new JList();
		
		JLabel lblNewLabel = new JLabel("Ready Queue");
		JLabel lblBlockingList = new JLabel("Blocked List");
		
		nameTextBox = new JTextField();
		nameTextBox.setColumns(10);
		
		priorityTextBox = new JTextField();
		priorityTextBox.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		JLabel lblNewLabel_2 = new JLabel("Priority");
		
		JButton btnNewButton = new JButton("Add New Process");
		btnNewButton.setAction(addProcess);
		
		JButton blKillButton = new JButton("Kill");
		blKillButton.setAction(bKill);
		JButton blRunButton = new JButton("Run");
		blRunButton.setAction(bRun);
		
		JLabel lblNewLabel_3 = new JLabel("CPU");
		lblRunningProcess = new JLabel("No Process Running");
		lblRunningProcess.setHorizontalAlignment(SwingConstants.CENTER);
		
		JButton blUnblockButton = new JButton("Unblock");
		blUnblockButton.setAction(bUnblock);
		JButton pqKillButton = new JButton("Kill");
		pqKillButton.setAction(pqKill);
		JButton pqBlockButton = new JButton("Block");
		pqBlockButton.setAction(pqBlock);
		JButton pqRunButton = new JButton("Run");
		pqRunButton.setAction(pqRun);
		
		JLabel lblPid = new JLabel("PID             Name            Priority            Status");
		
		JLabel label = new JLabel("PID             Name            Priority            Status");
		
		JButton cpuStopButton = new JButton("Stop");
		cpuStopButton.setAction(cpuStop);
		
		JButton cpuKillButton = new JButton("Kill");
		cpuKillButton.setAction(cpuKill);
		
		JButton cpuBlockButton = new JButton("Block");
		cpuBlockButton.setAction(cpuBlock);
		
		JLabel label_1 = new JLabel("PID             Name            Priority            Status");
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(155)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addComponent(lblPid, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGap(4)
										.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
											.addGroup(gl_contentPane.createSequentialGroup()
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(pqKillButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(pqBlockButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(pqRunButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
											.addComponent(pqList, GroupLayout.PREFERRED_SIZE, 236, GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(ComponentPlacement.RELATED, 37, Short.MAX_VALUE))))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(70)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addPreferredGap(ComponentPlacement.RELATED)
											.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_contentPane.createSequentialGroup()
													.addComponent(blKillButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(ComponentPlacement.RELATED)
													.addComponent(blUnblockButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(ComponentPlacement.RELATED)
													.addComponent(blRunButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
												.addComponent(bList, GroupLayout.PREFERRED_SIZE, 252, GroupLayout.PREFERRED_SIZE)))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(80)
											.addComponent(lblBlockingList)))
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(218)
											.addComponent(lblNewLabel_3))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addGap(90)
											.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
												.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)
												.addGroup(gl_contentPane.createSequentialGroup()
													.addComponent(cpuKillButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(ComponentPlacement.RELATED)
													.addComponent(cpuBlockButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(ComponentPlacement.RELATED)
													.addComponent(cpuStopButton, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE))
												.addComponent(lblRunningProcess, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)))))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(78)
									.addComponent(label, GroupLayout.PREFERRED_SIZE, 256, GroupLayout.PREFERRED_SIZE)))
							.addGap(101))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(184)
							.addComponent(nameTextBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(priorityTextBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnNewButton))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(213)
							.addComponent(lblNewLabel_1)
							.addGap(65)
							.addComponent(lblNewLabel_2)))
					.addGap(54))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(36)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(lblNewLabel_2))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(priorityTextBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(nameTextBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(106)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_3)
						.addComponent(lblBlockingList))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblPid)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(label)
							.addComponent(label_1)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(pqList, GroupLayout.PREFERRED_SIZE, 237, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(6)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
										.addComponent(bList, GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblRunningProcess))))
							.addGap(14)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(blKillButton)
								.addComponent(blUnblockButton)
								.addComponent(blRunButton)
								.addComponent(pqKillButton)
								.addComponent(pqBlockButton)
								.addComponent(pqRunButton)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(136)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(cpuKillButton)
								.addComponent(cpuBlockButton)
								.addComponent(cpuStopButton))))
					.addContainerGap(219, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	// add process
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Add New Process");
			putValue(SHORT_DESCRIPTION, "Adds a new process to the Ready Queue.");
		}
		public void actionPerformed(ActionEvent e) {
			DefaultListModel DLM = new DefaultListModel();
			d1.addProcessToQueue(new Process(Integer.parseInt(priorityTextBox.getText()), nameTextBox.getText(),(int)(9999*(Math.random())), ""));
			DLM.clear();
			//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] priorityQueueArray = d1.getReadyQueue().toArray();
			
			for(int x=0;x<priorityQueueArray.length;x++)
			{
				 DLM.addElement(priorityQueueArray[x]);
				//DLM.addElement(((Process)d1.getReadyQueue().toArray()[x]).getName());	
			}
			
			
			priorityTextBox.setText("");
			nameTextBox.setText("");
			
			pqList.setModel(DLM);
			

		}
	}
	
	// priorityqueue kill
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "Kill");
			putValue(SHORT_DESCRIPTION, "Kills process currently in the Ready Queue.");
		}
		public void actionPerformed(ActionEvent e) {
			
			DefaultListModel DLM = new DefaultListModel();
			d1.killProcessInQueue((Process)pqList.getSelectedValue());
			DLM.clear();
			//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] priorityQueueArray = d1.getReadyQueue().toArray();
			for(int x=0;x<priorityQueueArray.length;x++)
			{
				 DLM.addElement(priorityQueueArray[x]);
				
			}
			
			
			
			pqList.setModel(DLM);
		}
	}
	
	//priority queue block
	private class SwingAction_2 extends AbstractAction {
		public SwingAction_2() {
			putValue(NAME, "Block");
			putValue(SHORT_DESCRIPTION, "Block process.");
		}
		public void actionPerformed(ActionEvent e) {
			
			// block process in PQ
			d1.blockProcessInQueue((Process)pqList.getSelectedValue());
			
			// set and add the model for the pq list
			DefaultListModel DLM = new DefaultListModel();
			DLM.clear();
			//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
	
			Object[] priorityQueueArray = d1.getReadyQueue().toArray();
			for(int x=0;x<priorityQueueArray.length;x++)
			{
				 DLM.addElement(priorityQueueArray[x]);
				
			}
			
			pqList.setModel(DLM);
			// set and add the model for the blocking list
			
			DefaultListModel DLM2 = new DefaultListModel();
			DLM2.clear();
			//DLM2.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] blockingListArray = d1.getBlockingList().toArray();
			for(int x=0;x<blockingListArray.length;x++)
			{
				 DLM2.addElement(blockingListArray[x]);
				
			}
			
			bList.setModel(DLM2);
		}
	}
	
	// pq run
	private class SwingAction_3 extends AbstractAction {
		public SwingAction_3() {
			putValue(NAME, "Run");
			putValue(SHORT_DESCRIPTION, "Run process currently in the Ready Queue.");
		}
		public void actionPerformed(ActionEvent e) {
			
			// run particular process
			d1.runProcessInQueue((Process)pqList.getSelectedValue());
			
			// update priority queue list
			DefaultListModel DLM = new DefaultListModel();
			DLM.clear();
			//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
	
			Object[] priorityQueueArray = d1.getReadyQueue().toArray();
			for(int x=0;x<priorityQueueArray.length;x++)
			{
				 DLM.addElement(priorityQueueArray[x]);
				
			}
			
			pqList.setModel(DLM);
			
			// update cpu label
			lblRunningProcess.setText(d1.getCpu().toString());
			
			
			
		}
	}
	private class SwingAction_4 extends AbstractAction {
		public SwingAction_4() {
			putValue(NAME, "Kill");
			putValue(SHORT_DESCRIPTION, "Kill process in the Blocked List. ");
		}
		public void actionPerformed(ActionEvent e) {
			
			// kill process in blockingList
			d1.killProcessInList((Process)bList.getSelectedValue());
			
			// update blockinglist
			DefaultListModel DLM2 = new DefaultListModel();
			DLM2.clear();
			//DLM2.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] blockingListArray = d1.getBlockingList().toArray();
			for(int x=0;x<blockingListArray.length;x++)
			{
				 DLM2.addElement(blockingListArray[x]);
				
			}
			
			bList.setModel(DLM2);
		}
	}
	
	//unblock blocking list
	private class SwingAction_5 extends AbstractAction {
		public SwingAction_5() {
			putValue(NAME, "Unblock");
			putValue(SHORT_DESCRIPTION, "Unblock process in the Blocked List.");
		}
		public void actionPerformed(ActionEvent e) {
			
			// return process to ready queue
			d1.unblockProcessInList((Process)bList.getSelectedValue());
			
						// set and add the model for the pq list
						DefaultListModel DLM = new DefaultListModel();
						DLM.clear();
						//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
				
						Object[] priorityQueueArray = d1.getReadyQueue().toArray();
						for(int x=0;x<priorityQueueArray.length;x++)
						{
							 DLM.addElement(priorityQueueArray[x]);
							
						}
						
						pqList.setModel(DLM);
						// set and add the model for the blocking list
						
						DefaultListModel DLM2 = new DefaultListModel();
						DLM2.clear();
						//DLM2.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
						Object[] blockingListArray = d1.getBlockingList().toArray();
						for(int x=0;x<blockingListArray.length;x++)
						{
							 DLM2.addElement(blockingListArray[x]);
							
						}
						
						bList.setModel(DLM2);
		}
	}
	
	// run process in blocking list
	private class SwingAction_6 extends AbstractAction {
		public SwingAction_6() {
			putValue(NAME, "Run");
			putValue(SHORT_DESCRIPTION, "Run Process.");
		}
		public void actionPerformed(ActionEvent e) {
			
			// run particular process
						d1.runProcessInList((Process)bList.getSelectedValue());
						
						// update blocking  list
						DefaultListModel DLM = new DefaultListModel();
						DLM.clear();
						//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
				
						Object[] blockingListArray = d1.getBlockingList().toArray();
						for(int x=0;x<blockingListArray.length;x++)
						{
							 DLM.addElement(blockingListArray[x]);
							
						}
						
						bList.setModel(DLM);
						
						// update cpu label
						lblRunningProcess.setText(d1.getCpu().toString());
		}
	}
	
	// cpu kill process
	private class SwingAction_7 extends AbstractAction {
		public SwingAction_7() {
			putValue(NAME, "Kill");
			putValue(SHORT_DESCRIPTION, "Kill process.");
		}
		public void actionPerformed(ActionEvent e) {
			
			// kill process in cpu
			d1.killProcessInCpu(d1.getCpu());
						
			// update cpu label to none 
			lblRunningProcess.setText("No Process Running");			
		}
	}
	
	// cpu block process
	private class SwingAction_8 extends AbstractAction {
		public SwingAction_8() {
			putValue(NAME, "Block");
			putValue(SHORT_DESCRIPTION, "Block process in CPU.");
		}
		public void actionPerformed(ActionEvent e) {
			
			d1.blockProcessInCpu(d1.getCpu());
			
			lblRunningProcess.setText("No Process Running");
			
			// update blockinglist
			DefaultListModel DLM2 = new DefaultListModel();
			DLM2.clear();
			//DLM2.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] blockingListArray = d1.getBlockingList().toArray();
			for(int x=0;x<blockingListArray.length;x++)
			{
				 DLM2.addElement(blockingListArray[x]);
							
			}
						
			bList.setModel(DLM2);			
			
		}
	}
	private class SwingAction_9 extends AbstractAction {
		public SwingAction_9() {
			putValue(NAME, "Stop");
			putValue(SHORT_DESCRIPTION, "Stop process in CPU.");
		}
		public void actionPerformed(ActionEvent e) {
			
			d1.stopProcessInCpu(d1.getCpu());
			
			lblRunningProcess.setText("No Process Running");
			
			// set and add the model for the pq list
			DefaultListModel DLM = new DefaultListModel();
			DLM.clear();
			//DLM.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
	
			Object[] priorityQueueArray = d1.getReadyQueue().toArray();
			for(int x=0;x<priorityQueueArray.length;x++)
			{
				 DLM.addElement(priorityQueueArray[x]);
				
			}
			
			pqList.setModel(DLM);
			// set and add the model for the blocking list
			
			DefaultListModel DLM2 = new DefaultListModel();
			DLM2.clear();
			//DLM2.addElement("pid" + "      " + "name" + "      " + "priority" +"      " + "status");
			Object[] blockingListArray = d1.getBlockingList().toArray();
			for(int x=0;x<blockingListArray.length;x++)
			{
				 DLM2.addElement(blockingListArray[x]);
				
			}
			
			bList.setModel(DLM2);			
		}
	}
}
