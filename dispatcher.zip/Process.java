package dispatchsimulator;

// Process is the basic unit manipulated by the 
// priority Queue, blockedList, and CPU

public class Process implements Comparable<Process>{
// pid name priority status
	
private int pid;
private String name;
private int priority;
private String status;

public Process()
{
	
	pid = -1;
	name = "undefined";
	priority = -1;	
	status = "undefined";
	
		
}

public Process(int inPid, String inName, int inPriority, String inStatus)
// status can be "running" "ready" "blocked" or "undefined"
{
	pid = inPid;
	name = inName;
	priority = inPriority;
	status = inStatus;
}


//setter only for status because thats all you should be able to change

public void setStatus(String newStatus)
{
	if(newStatus =="running")
		status = newStatus;
	else if(newStatus =="ready")
		status = newStatus;
	else if(newStatus =="blocked")
		status = newStatus;
	else
		System.out.println("Error: Invalid Status '" + newStatus + "'") ;		
}

// getters for all
public int getPid()
{
	return pid;
}

public String getName()
{
	return name;
}

public int getPriority()
{
	return priority;
}

public String getStatus()
{
	return status;
}

// does it by name but it is ok for now
public int compareTo(Process p) {
	// TODO Auto-generated method stub
	
	if(this.pid < p.pid)
		return 1;
	else if(this.pid > p.pid)
		return -1;
	else
		return 0;

}

@Override
public String toString()
{
	return(priority + "          " + name + "         " + pid +"              " + status);
}


}